const express = require('express');
const cors = require('cors');
const miembrosRoutes = require('./routes/miembros');
const graficasRoutes = require('./routes/graficas');

const app = express();
const PORT = 3001;

// Middlewares
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));
app.use(express.json());

// Rutas de la API
app.use('/api/miembros', miembrosRoutes);
app.use('/api/graficas', graficasRoutes);

// Ruta raíz
app.get('/', (req, res) => {
    res.json({ message: 'API Atlantic City funcionando correctamente' });
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
