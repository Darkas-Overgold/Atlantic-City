const mysql = require('mysql2');

/**
 * Pool de conexiones a la base de datos MySQL
 */
const pool = mysql.createPool({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '',
  database: 'atlantic_city',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool.promise();
