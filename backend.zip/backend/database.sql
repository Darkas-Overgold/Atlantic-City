-- Script para crear la base de datos y tabla de miembros
-- Ejecutar en MySQL Workbench o línea de comandos

-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS atlantic_city;

-- Usar la base de datos
USE atlantic_city;

-- Crear tabla de miembros
CREATE TABLE IF NOT EXISTS miembros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombres VARCHAR(100) NOT NULL,
  apellidos VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  categoria ENUM('Oro', 'Plata', 'Bronce') DEFAULT 'Bronce',
  telefono VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar datos de ejemplo
INSERT INTO miembros (nombres, apellidos, email, categoria, telefono) VALUES
('Mark', 'Otto', 'mark@example.com', 'Oro', '987456321'),
('Jacob', 'Thornton', 'jacob@example.com', 'Bronce', '987456322'),
('Larry', 'Bird', 'larry@example.com', 'Plata', '987456323'),
('John', 'Doe', 'john@example.com', 'Oro', '987456324'),
('Jane', 'Smith', 'jane@example.com', 'Plata', '987456325');

-- Verificar los datos
SELECT * FROM miembros;
