const db = require('../config/database');

/**
 * Modelo Miembro - Operaciones CRUD para la tabla miembros
 */
class Miembro {
    /** Obtener todos los miembros */
    static async findAll() {
        const [rows] = await db.query('SELECT * FROM miembros ORDER BY id DESC');
        return rows;
    }

    /** Obtener un miembro por ID */
    static async findById(id) {
        const [rows] = await db.query('SELECT * FROM miembros WHERE id = ?', [id]);
        return rows[0];
    }

    /** Crear un nuevo miembro */
    static async create(miembro) {
        const { nombres, apellidos, email, categoria, telefono } = miembro;
        const [result] = await db.query(
            'INSERT INTO miembros (nombres, apellidos, email, categoria, telefono) VALUES (?, ?, ?, ?, ?)',
            [nombres, apellidos, email, categoria, telefono]
        );
        return { id: result.insertId, ...miembro };
    }

    /** Actualizar un miembro existente */
    static async update(id, miembro) {
        const { nombres, apellidos, email, categoria, telefono } = miembro;
        await db.query(
            'UPDATE miembros SET nombres = ?, apellidos = ?, email = ?, categoria = ?, telefono = ? WHERE id = ?',
            [nombres, apellidos, email, categoria, telefono, id]
        );
        return { id, ...miembro };
    }

    /** Eliminar un miembro */
    static async delete(id) {
        await db.query('DELETE FROM miembros WHERE id = ?', [id]);
        return { id };
    }

    /** Obtener estadísticas agrupadas por categoría */
    static async getEstadisticasPorCategoria() {
        const [rows] = await db.query(
            'SELECT categoria, COUNT(*) as cantidad FROM miembros GROUP BY categoria'
        );
        return rows;
    }
}

module.exports = Miembro;
