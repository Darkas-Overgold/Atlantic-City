const express = require('express');
const router = express.Router();
const Miembro = require('../models/Miembro');

/** GET /api/graficas/categorias - Datos para gráfico circular */
router.get('/categorias', async (req, res) => {
    try {
        const estadisticas = await Miembro.getEstadisticasPorCategoria();
        const labels = estadisticas.map(e => e.categoria || 'Sin categoría');
        const series = estadisticas.map(e => e.cantidad);
        res.json({ labels, series });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/** GET /api/graficas/rendimiento - Datos para gráfico de columnas */
router.get('/rendimiento', async (req, res) => {
    try {
        const data = {
            categories: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
            series: [{
                name: 'Sesiones',
                data: [44, 55, 57, 56, 61, 58, 63]
            }]
        };
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/** GET /api/graficas/resumen - Datos generales del dashboard */
router.get('/resumen', async (req, res) => {
    try {
        const estadisticas = await Miembro.getEstadisticasPorCategoria();
        const totalMiembros = estadisticas.reduce((sum, e) => sum + e.cantidad, 0);
        res.json({
            totalMiembros,
            porCategoria: estadisticas,
            ventas: [44, 55, 13, 43, 22],
            meses: ['Ene', 'Feb', 'Mar', 'Abr', 'May']
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
