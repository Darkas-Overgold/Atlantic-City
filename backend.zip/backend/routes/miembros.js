const express = require('express');
const router = express.Router();
const Miembro = require('../models/Miembro');

/* GET /api/miembros - Listar todos los miembros */
router.get('/', async (req, res) => {
    try {
        const miembros = await Miembro.findAll();
        res.json(miembros);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/* GET /api/miembros/:id - Obtener un miembro por ID */
router.get('/:id', async (req, res) => {
    try {
        const miembro = await Miembro.findById(req.params.id);
        if (!miembro) {
            return res.status(404).json({ error: 'Miembro no encontrado' });
        }
        res.json(miembro);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/* POST /api/miembros - Crear un nuevo miembro */
router.post('/', async (req, res) => {
    try {
        const nuevoMiembro = await Miembro.create(req.body);
        res.status(201).json(nuevoMiembro);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/* PUT /api/miembros/:id - Actualizar un miembro */
router.put('/:id', async (req, res) => {
    try {
        const miembroActualizado = await Miembro.update(req.params.id, req.body);
        res.json(miembroActualizado);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/* DELETE /api/miembros/:id - Eliminar un miembro */
router.delete('/:id', async (req, res) => {
    try {
        await Miembro.delete(req.params.id);
        res.json({ message: 'Miembro eliminado correctamente' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
